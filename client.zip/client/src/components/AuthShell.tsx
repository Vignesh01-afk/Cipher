import type { ReactNode } from 'react';
import { Key, ShieldCheck, Wallet } from '@phosphor-icons/react';
import BrandMark from './BrandMark';

/**
 * Split-screen auth shell from the reference mockup:
 *
 *  - Left: the brand panel - gradient padlock, split wordmark, tagline,
 *    "Secure • Encrypted • Yours" and (in dark mode) the three trust chips.
 *  - Right: the form card.
 *  - Background: soft aurora waves, light periwinkle by day and deep
 *    indigo-navy with glowing waves by night.
 *
 * On phones the brand panel collapses to a compact centred header above the
 * card so the form stays the focus.
 */

interface AuthShellProps {
  children: ReactNode;
  /** Card width; register needs a touch more room than sign-in. */
  width?: 'md' | 'lg';
}

const TRUST_CHIPS = [
  { icon: Key, label: 'End-to-End', sub: 'Encryption' },
  { icon: ShieldCheck, label: 'Secure', sub: 'Sharing' },
  { icon: Wallet, label: 'Full', sub: 'Control' },
];

export function AuthShell({ children, width = 'md' }: AuthShellProps): React.ReactElement {
  return (
    <div className="relative flex min-h-screen overflow-hidden bg-stone-100 aurora-bg dark:bg-[#0A0E23] dark:aurora-bg-dark">
      {/* Decorative waves + orbs; purely visual. */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-32 top-[-18%] h-[28rem] w-[28rem] rounded-md bg-[#4A6CF7]/20 blur-3xl dark:bg-[#4A6CF7]/25" />
        <div className="absolute -right-24 top-[6%] h-[24rem] w-[24rem] rounded-md bg-[#D946EF]/20 blur-3xl dark:bg-[#D946EF]/20" />
        <div className="absolute bottom-[-24%] left-1/3 h-[30rem] w-[30rem] rounded-md bg-[#8B5CF6]/20 blur-3xl dark:bg-[#8B5CF6]/25" />

        {/* Wave bands along the bottom, echoing the mockup artwork. */}
        <svg
          className="absolute bottom-0 left-0 h-64 w-full opacity-70 dark:opacity-60"
          viewBox="0 0 1440 320"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="auth-wave-1" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#4A6CF7" stopOpacity="0.45" />
              <stop offset="50%" stopColor="#8B5CF6" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#D946EF" stopOpacity="0.45" />
            </linearGradient>
            <linearGradient id="auth-wave-2" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#4A6CF7" stopOpacity="0.3" />
            </linearGradient>
          </defs>
          <path
            fill="url(#auth-wave-2)"
            d="M0,224L60,213.3C120,203,240,181,360,181.3C480,181,600,203,720,213.3C840,224,960,224,1080,208C1200,192,1320,160,1380,144L1440,128L1440,320L0,320Z"
          />
          <path
            fill="url(#auth-wave-1)"
            d="M0,256L80,250.7C160,245,320,235,480,240C640,245,800,267,960,272C1120,277,1280,267,1360,261.3L1440,256L1440,320L0,320Z"
          />
        </svg>
      </div>

      <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-10 px-5 py-10 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:px-8">
        {/* ---------- Brand panel ---------- */}
        <div className="flex flex-col items-center text-center lg:items-start lg:text-left">
          <div className="flex items-center gap-3 lg:gap-4">
            <BrandMark size="lg" />
            <span className="text-3xl brand-wordmark sm:text-4xl">
              <span className="brand-wordmark-cipher">Cipher</span>
              <span className="brand-wordmark-note">Note</span>
            </span>
          </div>

          <p className="mt-5 text-base font-medium text-stone-600 dark:text-stone-300">
            Your notes. Your privacy. Always.
          </p>

          {/* Trust chips (dark mockup shows these with hexagon icons). */}
          <div className="mt-8 hidden gap-6 lg:flex">
            {TRUST_CHIPS.map((chip) => (
              <div key={chip.label} className="flex flex-col items-center gap-2 text-center">
                <span className="flex h-11 w-11 items-center justify-center rounded-md border border-white/60 bg-surface/70 text-[#4A6CF7]  dark:border-white/10 dark:bg-surface/[0.06] dark:text-[#A3B4FF]">
                  <chip.icon className="h-5 w-5" />
                </span>
                <span className="text-[11px] font-semibold leading-tight text-stone-600 dark:text-stone-300">
                  {chip.label}
                  <br />
                  {chip.sub}
                </span>
              </div>
            ))}
          </div>

          <p className="mt-10 hidden items-center gap-3 text-xs font-medium uppercase tracking-[0.2em] text-stone-500 dark:text-stone-400 lg:flex">
            <span>Secure</span>
            <span className="h-1 w-1 rounded-md bg-current opacity-60" />
            <span>Encrypted</span>
            <span className="h-1 w-1 rounded-md bg-current opacity-60" />
            <span>Yours</span>
          </p>
        </div>

        {/* ---------- Form ---------- */}
        <div className={`w-full ${width === 'lg' ? 'max-w-lg' : 'max-w-md'} mx-auto`}>
          <div className="card-glass p-6 sm:p-8">{children}</div>

          <p className="mt-5 text-center text-xs leading-5 text-stone-500 dark:text-stone-400 lg:hidden">
            Secure • Encrypted • Yours
          </p>
        </div>
      </div>
    </div>
  );
}
