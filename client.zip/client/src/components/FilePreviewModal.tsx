import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { File as FileIcon, FileText, FilmSlate, Image as ImageIcon, MusicNote, ShieldCheck, Trash } from '@phosphor-icons/react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { downloadAndDecryptFile, safePreviewKind, TEXT_MIME_TYPES, type SecureFileWithNoteKey } from '../lib/files';
import { formatBytes, formatDateTime } from '../lib/format';
import { Modal } from './Modal';
import { Spinner } from './Spinner';
import { ErrorState } from './States';

/**
 * Decrypted text previews larger than this are truncated in the <pre>; the
 * full plaintext stays in memory and never touches the DOM all at once.
 */
const MAX_TEXT_PREVIEW_CHARS = 250_000;

/**
 * Secure file viewer.
 *
 * - Downloads ciphertext via the authorised endpoint and decrypts it in memory.
 * - Creates an in-memory object URL for preview only. There is deliberately
 *   NO save/export affordance: decrypted bytes never touch the disk from here.
 * - The object URL is revoked and state cleared on close or on unmount.
 */
export function FilePreviewModal({
  file,
  noteKey,
  canDelete,
  onClose,
  onDeleted,
}: {
  file: SecureFileWithNoteKey | null;
  noteKey?: CryptoKey;
  canDelete: boolean;
  onClose: () => void;
  onDeleted?: () => void;
}): React.ReactElement | null {
  const { keys } = useAuth();
  const toast = useToast();
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const urlRef = useRef<string | null>(null);

  const revoke = useCallback(() => {
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current);
      urlRef.current = null;
    }
    setBlobUrl(null);
    setTextContent(null);
  }, []);

  /** For text/plain previews we read the plaintext bytes out of the Blob so we
   * can render them as static text in a <pre> instead of handing a blob URL to
   * a renderer.
   */
  const [textContent, setTextContent] = useState<string | null>(null);

  useEffect(() => {
    if (!file || !keys) {
      revoke();
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);

    downloadAndDecryptFile(file, keys, noteKey)
      .then(async (blob) => {
        if (cancelled) return;
        if (safePreviewKind(file.mimeType) === 'text') {
          // text/plain: decode the bytes here and render static text in a
          // <pre>. No object URL, no iframe, no script execution path.
          const decoded = await blob.text();
          if (cancelled) return;
          setTextContent(decoded);
          return;
        }
        const url = URL.createObjectURL(blob);
        urlRef.current = url;
        setBlobUrl(url);
      })
      .catch((downloadError: unknown) => {
        if (cancelled) return;
        setError(downloadError instanceof Error ? downloadError.message : 'Could not decrypt this file.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
      revoke();
    };
  }, [file, keys, noteKey, revoke]);

  async function handleDelete(): Promise<void> {
    if (!file) return;
    try {
      await api.deleteFile(file.id);
      toast.success('File deleted', 'The encrypted blob was removed from the server.');
      revoke();
      onDeleted?.();
      onClose();
    } catch (deleteError) {
      toast.error('Could not delete the file', deleteError instanceof Error ? deleteError.message : undefined);
    }
  }

  if (!file) return null;

  // `file.mimeType` is attacker-controllable metadata (set by the uploader).
  // It must never decide whether the browser renders this payload in an
  // executable context. Use the allowlist-derived preview kind, which renders
  // images/audio/video natively, renders text/plain as static text, renders
  // PDFs in a sandboxed iframe, and treats everything else (including
  // text/html and image/svg+xml) as "no preview".
  const kind = safePreviewKind(file.mimeType);

  return (
    <Modal
      open
      onClose={onClose}
      title={file.filename}
      description={`${formatBytes(file.plaintextBytes)} · decrypted in memory only`}
      size="lg"
      footer={
        <>
          {canDelete ? (
            <button
              type="button"
              className="btn btn-danger btn-sm"
              onClick={() => void handleDelete()}
            >
              <Trash className="h-3.5 w-3.5" />
              Delete
            </button>
          ) : null}
        </>
      }
    >
      {loading ? (
        <div className="flex flex-col items-center gap-3 py-10 text-sm text-stone-500 dark:text-stone-400">
          <Spinner className="h-5 w-5" />
          Downloading and decrypting in memory…
        </div>
      ) : error ? (
        <ErrorState title="Could not open this file" message={error} />
      ) : blobUrl && kind === 'image' ? (
        <div className="overflow-hidden rounded-md border border-stone-200 bg-stone-950/5 dark:border-stone-800 dark:bg-stone-950/40">
          <img
            src={blobUrl}
            alt={file.filename}
            className="mx-auto max-h-[60vh] w-auto select-none"
            draggable={false}
            onContextMenu={(event) => event.preventDefault()}
          />
        </div>
      ) : blobUrl && kind === 'video' ? (
        <video src={blobUrl} controls className="mx-auto max-h-[60vh] w-full rounded-md" />
      ) : blobUrl && kind === 'audio' ? (
        <audio src={blobUrl} controls className="w-full" />
      ) : textContent !== null ? (
        <pre
          className="max-h-[60vh] overflow-auto rounded-md bg-stone-950/5 dark:bg-stone-950/40 p-4 text-xs font-mono leading-5 text-stone-800 dark:text-stone-200"
          style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
          aria-label={`Decrypted file contents: ${file.filename}`}
        >
          {textContent.slice(0, MAX_TEXT_PREVIEW_CHARS)}
          {textContent.length > MAX_TEXT_PREVIEW_CHARS ? '\n\n… preview truncated …' : ''}
        </pre>
      ) : blobUrl && kind === 'pdf' ? (
        <iframe
          src={blobUrl}
          className="mx-auto max-h-[70vh] w-full rounded-md"
          sandbox=""
          title={`PDF preview for ${file.filename}`}
        />
      ) : blobUrl ? (
        <div className="flex flex-col items-center gap-3 py-10 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-md bg-stone-100 text-stone-500 dark:bg-stone-800 dark:text-stone-400">
            <FileIcon className="h-6 w-6" />
          </span>
          <p className="text-sm text-stone-600 dark:text-stone-300">
            No in-app preview is available for this file.
          </p>
          <p className="max-w-sm text-xs text-stone-500 dark:text-stone-400">
            Export is disabled for security: the decrypted bytes only exist in this tab's memory and are never written to disk.
          </p>
        </div>
      ) : null}

      <p className="mt-4 flex items-start gap-2 rounded-md border border-orange-200 bg-orange-50/60 p-3 text-xs leading-5 text-orange-950 dark:border-orange-600/30 dark:bg-orange-600/5 dark:text-orange-100/90">
        <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        This preview came from ciphertext that was decrypted inside your browser. The server never saw the plaintext.
      </p>
    </Modal>
  );
}

/** Small icon by MIME family, used in file lists. */
export function FileKindIcon({ mime, className = 'h-4 w-4' }: { mime: string; className?: string }): React.ReactElement {
  if (mime.startsWith('image/')) return <ImageIcon className={className} />;
  if (mime.startsWith('video/')) return <FilmSlate className={className} />;
  if (mime.startsWith('audio/')) return <MusicNote className={className} />;
  if (mime === 'application/pdf' || TEXT_MIME_TYPES.has(mime)) return <FileText className={className} />;
  return <FileIcon className={className} />;
}
